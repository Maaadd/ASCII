# python_asciimatics
Tampilkan gambar dan animasi dengan python, support png,jpg dan gif

Langkah penggunaan :
1. Pastikan sudah memasang python dan asciimatics.

Untuk memasang Asciimatics bisa dengan ketik "pip install asciimatics" di Terminal/CMD

2.Buatlah gambar dengan format JPG, PNG atau GIF.

3.Buka omat.py lalu ubah teks dan namafile gambar.

4.Jalankan dengan "python omat.py"
